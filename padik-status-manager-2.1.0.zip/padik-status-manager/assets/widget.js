(function () {
    "use strict";

    function setStatus(card, state, label) {
        const dot = card.querySelector(".psm-status-dot");

        if (!dot) {
            return;
        }

        dot.className = "psm-status-dot " + state;
        dot.setAttribute("aria-label", label);
        card.dataset.status = state;
    }

    function mapStatus(status) {
        if (status === 1) {
            return ["is-online", "Online"];
        }

        if (status === 0) {
            return ["is-offline", "Offline"];
        }

        if (status === 2) {
            return ["is-pending", "Čeká na kontrolu"];
        }

        return ["is-unknown", "Neznámý stav"];
    }

    async function updateWidget(widget) {
        const cards = widget.querySelectorAll(".psm-status-card[data-monitor-id]");

        cards.forEach(function (card) {
            setStatus(card, "is-loading", "Načítání");
        });

        try {
            const separator = PSMWidget.endpoint.includes("?") ? "&" : "?";
            const response = await fetch(
                PSMWidget.endpoint + separator + "_=" + Date.now(),
                {
                    method: "GET",
                    cache: "no-store",
                    credentials: "same-origin"
                }
            );

            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }

            const data = await response.json();
            const heartbeatList = data.heartbeatList || {};

            cards.forEach(function (card) {
                const heartbeats = heartbeatList[card.dataset.monitorId];

                if (!Array.isArray(heartbeats) || heartbeats.length === 0) {
                    setStatus(card, "is-unknown", "Neznámý stav");
                    return;
                }

                const latest = heartbeats[heartbeats.length - 1];
                const mapped = mapStatus(latest.status);
                setStatus(card, mapped[0], mapped[1]);
            });
        } catch (error) {
            console.error("Padik Status Manager:", error);

            cards.forEach(function (card) {
                setStatus(card, "is-unknown", "Stav se nepodařilo načíst");
            });
        }
    }

    function init() {
        if (typeof PSMWidget === "undefined") {
            return;
        }

        const widgets = document.querySelectorAll("[data-psm-widget]");

        widgets.forEach(updateWidget);

        window.setInterval(function () {
            widgets.forEach(updateWidget);
        }, Number(PSMWidget.refreshInterval) || 30000);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();
