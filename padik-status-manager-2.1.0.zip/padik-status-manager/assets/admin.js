(function ($) {
    "use strict";

    const button = $("#psm-load-monitors");
    const container = $("#psm-monitor-list");

    if (!button.length || !container.length) {
        return;
    }

    function getSelectedIds() {
        const raw = container.attr("data-selected");

        if (!raw) {
            return [];
        }

        try {
            const selected = JSON.parse(raw);
            return selected.map(function (monitor) {
                return String(monitor.id);
            });
        } catch (error) {
            return [];
        }
    }

    function renderMonitors(monitors) {
        if (!monitors.length) {
            container.html("<p>" + PSMAdmin.texts.empty + "</p>");
            return;
        }

        const selectedIds = getSelectedIds();
        const groups = {};

        monitors.forEach(function (monitor) {
            const group = monitor.group || "Bez skupiny";

            if (!groups[group]) {
                groups[group] = [];
            }

            groups[group].push(monitor);
        });

        let html = "";

        Object.keys(groups).forEach(function (groupName) {
            html += '<div class="psm-monitor-group">';
            html += "<h3>" + $("<div>").text(groupName).html() + "</h3>";

            groups[groupName].forEach(function (monitor) {
                const id = String(monitor.id);
                const checked = selectedIds.includes(id) ? " checked" : "";

                html += '<label class="psm-monitor-item">';
                html += '<input type="checkbox" name="monitor_ids[]" value="' + id + '"' + checked + ">";
                html += "<span><strong>" + $("<div>").text(monitor.name).html() + "</strong>";
                html += '<small>ID ' + id + (monitor.type ? " · " + $("<div>").text(monitor.type).html() : "") + "</small>";
                html += "</span></label>";
            });

            html += "</div>";
        });

        container.html(html);
    }

    button.on("click", function () {
        button.prop("disabled", true);
        container.html('<p class="psm-loading">' + PSMAdmin.texts.loading + "</p>");

        $.post(PSMAdmin.ajaxUrl, {
            action: "psm_fetch_monitors",
            nonce: PSMAdmin.nonce
        })
            .done(function (response) {
                if (!response.success) {
                    const message = response.data && response.data.message
                        ? response.data.message
                        : PSMAdmin.texts.error;

                    container.html("<p class='psm-error'>" + $("<div>").text(message).html() + "</p>");
                    return;
                }

                renderMonitors(response.data.monitors || []);
            })
            .fail(function () {
                container.html("<p class='psm-error'>" + PSMAdmin.texts.error + "</p>");
            })
            .always(function () {
                button.prop("disabled", false);
            });
    });

    if (getSelectedIds().length) {
        button.trigger("click");
    }
})(jQuery);
