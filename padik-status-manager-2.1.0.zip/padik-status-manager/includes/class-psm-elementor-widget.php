<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class PSM_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'padik_status_list';
    }

    public function get_title() {
        return 'Padik Status List';
    }

    public function get_icon() {
        return 'eicon-alert';
    }

    public function get_categories() {
        return ['general'];
    }

    public function get_keywords() {
        return ['status', 'uptime', 'kuma', 'monitor', 'server'];
    }

    public function get_style_depends() {
        return ['psm-widget'];
    }

    public function get_script_depends() {
        return ['psm-widget'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'Obsah',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $lists = PSM_Plugin::instance()->get_lists();
        $options = ['' => 'Vyberte seznam'];

        foreach ($lists as $id => $list) {
            $options[$id] = $list['name'];
        }

        $this->add_control(
            'list_id',
            [
                'label' => 'Uložený seznam',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $options,
                'default' => '',
                'description' => 'Seznam vytvoříte v Nastavení → Padik Status Manager.',
            ]
        );

        $this->add_control(
            'alignment',
            [
                'label' => 'Zarovnání',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => 'Vlevo',
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => 'Na střed',
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => 'Vpravo',
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .psm-status' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'card_style_section',
            [
                'label' => 'Karty',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'card_width',
            [
                'label' => 'Šířka karty',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 120, 'max' => 500],
                    '%' => ['min' => 10, 'max' => 100],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 180,
                ],
                'selectors' => [
                    '{{WRAPPER}} .psm-status-card' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'gap',
            [
                'label' => 'Mezera mezi kartami',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 60],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '{{WRAPPER}} .psm-status' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => 'Pozadí karty',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .psm-status-card' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_border_color',
            [
                'label' => 'Barva okraje',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .psm-status-card' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_radius',
            [
                'label' => 'Zaoblení rohů',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 60],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 18,
                ],
                'selectors' => [
                    '{{WRAPPER}} .psm-status-card' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label' => 'Vnitřní odsazení',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .psm-status-card' =>
                        'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'text_style_section',
            [
                'label' => 'Text',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => 'Barva textu',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .psm-service-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'selector' => '{{WRAPPER}} .psm-service-name',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'dot_style_section',
            [
                'label' => 'Stavová tečka',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'dot_size',
            [
                'label' => 'Velikost',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 6, 'max' => 40],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 12,
                ],
                'selectors' => [
                    '{{WRAPPER}} .psm-status-dot' =>
                        'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'online_color',
            [
                'label' => 'Online',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#34c759',
                'selectors' => [
                    '{{WRAPPER}} .psm-status-dot.is-online' =>
                        'background: {{VALUE}}; box-shadow: 0 0 10px {{VALUE}}, 0 0 20px {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'offline_color',
            [
                'label' => 'Offline',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ff3b30',
                'selectors' => [
                    '{{WRAPPER}} .psm-status-dot.is-offline' =>
                        'background: {{VALUE}}; box-shadow: 0 0 10px {{VALUE}}, 0 0 20px {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'loading_color',
            [
                'label' => 'Načítání',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffcc00',
                'selectors' => [
                    '{{WRAPPER}} .psm-status-dot.is-loading' =>
                        'background: {{VALUE}}; box-shadow: 0 0 10px {{VALUE}}, 0 0 20px {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $list_id = isset($settings['list_id']) ? (string) $settings['list_id'] : '';

        if ($list_id === '') {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<div class="elementor-alert elementor-alert-info">';
                echo 'Vyberte uložený seznam v nastavení widgetu.';
                echo '</div>';
            }

            return;
        }

        echo PSM_Plugin::instance()->render_list($list_id);
    }

    protected function content_template() {
        ?>
        <#
        if (!settings.list_id) {
            #>
            <div class="elementor-alert elementor-alert-info">
                Vyberte uložený seznam v nastavení widgetu.
            </div>
            <#
        }
        #>
        <?php
    }
}
