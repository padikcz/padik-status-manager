# Padik Status Manager 2.1.0

WordPress plugin pro:

- připojení k veřejné Uptime Kuma status stránce,
- automatické načtení všech monitorů,
- vytváření více vlastních seznamů pomocí zaškrtávacích polí,
- úpravu a mazání seznamů,
- zobrazení pomocí shortcode,
- vlastní Elementor widget s výběrem uloženého seznamu,
- WordPress REST proxy bez problémů s CORS.

## Instalace

1. Ve WordPressu otevřete **Pluginy → Instalace pluginů → Nahrát plugin**.
2. Nahrajte ZIP.
3. Aktivujte plugin.
4. Otevřete **Nastavení → Padik Status Manager**.
5. Uložte adresu Uptime Kuma a slug status stránky.
6. Klikněte na **Načíst monitory z Uptime Kuma**.
7. Zaškrtněte monitory a vytvořte seznam.

## Shortcode

Po vytvoření seznamu plugin ukáže shortcode:

```text
[padik_status list="list_xxxxxxxx"]
```

## Elementor

V Elementoru vyhledejte widget:

```text
Padik Status List
```

V jeho nastavení zvolte jeden z uložených seznamů.

## Požadavky

- WordPress 6.0 nebo novější
- PHP 7.4 nebo novější
- veřejná Uptime Kuma Status Page
- Elementor je volitelný


## Oprava kritické chyby ve verzi 2.0.0

Verze 2.0.1 načítá Elementor widget až ve chvíli, kdy je Elementor připravený.
Pokud web spadl po aktivaci starší verze, přejmenujte její složku v
`wp-content/plugins/`, přihlaste se do administrace a nahrajte tuto verzi.


## Oprava ve verzi 2.0.2

Opravuje problém, kdy shortcode zobrazil hlášku `Vybraný seznam neexistuje`,
pokud ID seznamu obsahovalo velká písmena, například `list_OHPZIaew`.


## Oprava ve verzi 2.0.3

Tlačítko **Upravit** nyní načte název seznamu i dříve vybrané monitory zpět do části
**2. Vytvořit vlastní seznam**. Po změně výběru lze seznam znovu uložit tlačítkem
**Aktualizovat seznam**.


## Elementor ve verzi 2.1.0

Plugin obsahuje vlastní widget **Padik Status List**.

V Elementoru:

1. Otevřete editor stránky.
2. Vyhledejte widget `Padik Status List`.
3. Přetáhněte ho na stránku.
4. Vyberte uložený seznam.
5. V záložce **Styl** můžete změnit šířku karet, mezery, barvy, typografii,
   zaoblení, odsazení a velikost stavové tečky.
