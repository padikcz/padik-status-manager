<?php
/**
 * Plugin Name: Padik Status Manager
 * Description: Správa vlastních seznamů monitorů z Uptime Kuma, shortcode a Elementor widget.
 * Version: 2.1.0
 * Author: padikcz
 * License: GPL-2.0-or-later
 * Text Domain: padik-status-manager
 */

if (!defined('ABSPATH')) {
    exit;
}

define('PSM_VERSION', '2.1.0');
define('PSM_FILE', __FILE__);
define('PSM_DIR', plugin_dir_path(__FILE__));
define('PSM_URL', plugin_dir_url(__FILE__));

require_once PSM_DIR . 'includes/class-psm-plugin.php';

register_activation_hook(__FILE__, ['PSM_Plugin', 'activate']);

PSM_Plugin::instance();
