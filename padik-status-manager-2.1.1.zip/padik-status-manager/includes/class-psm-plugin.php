<?php

if (!defined('ABSPATH')) {
    exit;
}

final class PSM_Plugin {
    const SETTINGS_OPTION = 'psm_settings';
    const LISTS_OPTION = 'psm_lists';

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate() {
        if (get_option(self::SETTINGS_OPTION, null) === null) {
            add_option(self::SETTINGS_OPTION, [
                'kuma_url' => 'https://status.padik.eu',
                'slug' => 'default',
                'refresh_interval' => 30,
            ]);
        }

        if (get_option(self::LISTS_OPTION, null) === null) {
            add_option(self::LISTS_OPTION, []);
        }
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'register_admin_page']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);

        add_action('wp_ajax_psm_fetch_monitors', [$this, 'ajax_fetch_monitors']);
        add_action('admin_post_psm_save_settings', [$this, 'save_settings']);
        add_action('admin_post_psm_save_list', [$this, 'save_list']);
        add_action('admin_post_psm_delete_list', [$this, 'delete_list']);

        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('wp_enqueue_scripts', [$this, 'register_front_assets']);
        add_action('elementor/frontend/after_register_styles', [$this, 'register_front_assets']);
        add_action('elementor/frontend/after_register_scripts', [$this, 'register_front_assets']);
        add_shortcode('padik_status', [$this, 'shortcode']);

        add_action('plugins_loaded', [$this, 'maybe_register_elementor']);
        add_filter('plugin_action_links_' . plugin_basename(PSM_FILE), [$this, 'plugin_links']);
    }

    public function get_settings() {
        $defaults = [
            'kuma_url' => 'https://status.padik.eu',
            'slug' => 'default',
            'refresh_interval' => 30,
        ];

        $saved = get_option(self::SETTINGS_OPTION, []);

        return wp_parse_args(is_array($saved) ? $saved : [], $defaults);
    }

    public function get_lists() {
        $lists = get_option(self::LISTS_OPTION, []);
        return is_array($lists) ? $lists : [];
    }

    public function register_admin_page() {
        add_options_page(
            'Padik Status Manager',
            'Padik Status Manager',
            'manage_options',
            'padik-status-manager',
            [$this, 'render_admin_page']
        );
    }

    public function admin_assets($hook) {
        if ($hook !== 'settings_page_padik-status-manager') {
            return;
        }

        wp_enqueue_style(
            'psm-admin',
            PSM_URL . 'assets/admin.css',
            [],
            PSM_VERSION
        );

        wp_enqueue_script(
            'psm-admin',
            PSM_URL . 'assets/admin.js',
            ['jquery'],
            PSM_VERSION,
            true
        );

        wp_localize_script('psm-admin', 'PSMAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('psm_fetch_monitors'),
            'texts' => [
                'loading' => 'Načítám monitory…',
                'error' => 'Monitory se nepodařilo načíst.',
                'empty' => 'Na status stránce nejsou žádné monitory.',
            ],
        ]);
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get_settings();
        $lists = $this->get_lists();

        $requested_edit_id = isset($_GET['edit_list'])
            ? sanitize_text_field(wp_unslash($_GET['edit_list']))
            : '';

        $edit_id = $this->resolve_list_id($requested_edit_id, $lists);
        $edit_list = $edit_id && isset($lists[$edit_id]) ? $lists[$edit_id] : null;

        ?>
        <div class="wrap psm-wrap">
            <h1>Padik Status Manager</h1>

            <?php if (isset($_GET['psm_saved'])) : ?>
                <div class="notice notice-success is-dismissible"><p>Změny byly uloženy.</p></div>
            <?php endif; ?>

            <?php if (isset($_GET['psm_deleted'])) : ?>
                <div class="notice notice-success is-dismissible"><p>Seznam byl odstraněn.</p></div>
            <?php endif; ?>

            <div class="psm-grid">
                <section class="psm-panel">
                    <h2>1. Připojení k Uptime Kuma</h2>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="psm_save_settings">
                        <?php wp_nonce_field('psm_save_settings'); ?>

                        <label for="psm-kuma-url">Adresa Uptime Kuma</label>
                        <input
                            id="psm-kuma-url"
                            class="regular-text"
                            type="url"
                            name="kuma_url"
                            value="<?php echo esc_attr($settings['kuma_url']); ?>"
                            placeholder="https://status.example.com"
                            required
                        >

                        <label for="psm-slug">Slug veřejné status stránky</label>
                        <input
                            id="psm-slug"
                            class="regular-text"
                            type="text"
                            name="slug"
                            value="<?php echo esc_attr($settings['slug']); ?>"
                            placeholder="default"
                            required
                        >

                        <label for="psm-refresh">Obnovení stavu v sekundách</label>
                        <input
                            id="psm-refresh"
                            type="number"
                            name="refresh_interval"
                            min="10"
                            value="<?php echo esc_attr($settings['refresh_interval']); ?>"
                        >

                        <?php submit_button('Uložit připojení', 'primary', 'submit', false); ?>
                    </form>
                </section>

                <section class="psm-panel">
                    <h2>2. Vytvořit vlastní seznam</h2>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="psm-list-form">
                        <input type="hidden" name="action" value="psm_save_list">
                        <input type="hidden" name="list_id" value="<?php echo esc_attr($edit_id); ?>">
                        <?php wp_nonce_field('psm_save_list'); ?>

                        <label for="psm-list-name">Název seznamu</label>
                        <input
                            id="psm-list-name"
                            class="regular-text"
                            type="text"
                            name="list_name"
                            value="<?php echo esc_attr($edit_list['name'] ?? ''); ?>"
                            placeholder="Například Hlavní služby"
                            required
                        >

                        <div class="psm-actions-row">
                            <button type="button" class="button button-secondary" id="psm-load-monitors">
                                Načíst monitory z Uptime Kuma
                            </button>
                        </div>

                        <div
                            id="psm-monitor-list"
                            class="psm-monitor-list"
                            data-selected="<?php echo esc_attr(wp_json_encode($edit_list['monitors'] ?? [])); ?>"
                        >
                            <p class="description">Klikněte na „Načíst monitory z Uptime Kuma“.</p>
                        </div>

                        <?php submit_button(
                            $edit_list ? 'Aktualizovat seznam' : 'Vytvořit seznam',
                            'primary',
                            'submit',
                            false
                        ); ?>

                        <?php if ($edit_list) : ?>
                            <a class="button" href="<?php echo esc_url(admin_url('options-general.php?page=padik-status-manager')); ?>">
                                Zrušit úpravy
                            </a>
                        <?php endif; ?>
                    </form>
                </section>
            </div>

            <section class="psm-panel psm-lists-panel">
                <h2>3. Uložené seznamy</h2>

                <?php if (!$lists) : ?>
                    <p>Zatím nebyl vytvořen žádný seznam.</p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>Název</th>
                                <th>Monitory</th>
                                <th>Shortcode</th>
                                <th>Akce</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($lists as $list_id => $list) : ?>
                            <tr>
                                <td><strong><?php echo esc_html($list['name']); ?></strong></td>
                                <td>
                                    <?php
                                    $names = array_map(
                                        static function ($monitor) {
                                            return $monitor['name'];
                                        },
                                        $list['monitors']
                                    );
                                    echo esc_html(implode(', ', $names));
                                    ?>
                                </td>
                                <td>
                                    <code>[padik_status list="<?php echo esc_attr($list_id); ?>"]</code>
                                </td>
                                <td>
                                    <a
                                        class="button button-small"
                                        href="<?php echo esc_url(add_query_arg([
                                            'page' => 'padik-status-manager',
                                            'edit_list' => $list_id,
                                        ], admin_url('options-general.php'))); ?>"
                                    >
                                        Upravit
                                    </a>

                                    <a
                                        class="button button-small button-link-delete"
                                        href="<?php echo esc_url(wp_nonce_url(
                                            add_query_arg([
                                                'action' => 'psm_delete_list',
                                                'list_id' => $list_id,
                                            ], admin_url('admin-post.php')),
                                            'psm_delete_list_' . $list_id
                                        )); ?>"
                                        onclick="return confirm('Opravdu odstranit tento seznam?');"
                                    >
                                        Odstranit
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>

            <section class="psm-panel">
                <h2>Elementor</h2>
                <p>V Elementoru vyhledejte prvek <strong>Padik Status List</strong> a v jeho nastavení vyberte uložený seznam.</p>
            </section>
        </div>
        <?php
    }

    public function save_settings() {
        if (!current_user_can('manage_options')) {
            wp_die('Nemáte oprávnění.');
        }

        check_admin_referer('psm_save_settings');

        $settings = [
            'kuma_url' => isset($_POST['kuma_url'])
                ? esc_url_raw(untrailingslashit(wp_unslash($_POST['kuma_url'])))
                : '',
            'slug' => isset($_POST['slug'])
                ? sanitize_title(wp_unslash($_POST['slug']))
                : 'default',
            'refresh_interval' => isset($_POST['refresh_interval'])
                ? max(10, absint($_POST['refresh_interval']))
                : 30,
        ];

        update_option(self::SETTINGS_OPTION, $settings);

        wp_safe_redirect(add_query_arg(
            ['page' => 'padik-status-manager', 'psm_saved' => 1],
            admin_url('options-general.php')
        ));
        exit;
    }

    public function ajax_fetch_monitors() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Nemáte oprávnění.'], 403);
        }

        check_ajax_referer('psm_fetch_monitors', 'nonce');

        $result = $this->fetch_status_page_config();

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()], 502);
        }

        wp_send_json_success(['monitors' => $result]);
    }

    private function fetch_status_page_config() {
        $settings = $this->get_settings();

        $url = untrailingslashit($settings['kuma_url'])
            . '/api/status-page/'
            . rawurlencode($settings['slug']);

        $response = wp_remote_get($url, [
            'timeout' => 15,
            'redirection' => 3,
            'headers' => [
                'Accept' => 'application/json',
                'User-Agent' => 'Padik-Status-Manager/' . PSM_VERSION,
            ],
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($status !== 200 || !is_array($data)) {
            return new WP_Error('psm_invalid_response', 'Uptime Kuma vrátila neplatnou odpověď.');
        }

        $monitors = [];

        foreach (($data['publicGroupList'] ?? []) as $group) {
            foreach (($group['monitorList'] ?? []) as $monitor) {
                if (empty($monitor['id']) || empty($monitor['name'])) {
                    continue;
                }

                $monitors[] = [
                    'id' => absint($monitor['id']),
                    'name' => sanitize_text_field($monitor['name']),
                    'type' => sanitize_text_field($monitor['type'] ?? ''),
                    'group' => sanitize_text_field(trim($group['name'] ?? '')),
                ];
            }
        }

        return $monitors;
    }

    public function save_list() {
        if (!current_user_can('manage_options')) {
            wp_die('Nemáte oprávnění.');
        }

        check_admin_referer('psm_save_list');

        $name = isset($_POST['list_name'])
            ? sanitize_text_field(wp_unslash($_POST['list_name']))
            : '';

        $ids = isset($_POST['monitor_ids'])
            ? array_map('absint', (array) wp_unslash($_POST['monitor_ids']))
            : [];

        if ($name === '' || !$ids) {
            wp_die('Zadejte název a vyberte alespoň jeden monitor.');
        }

        $available = $this->fetch_status_page_config();

        if (is_wp_error($available)) {
            wp_die(esc_html($available->get_error_message()));
        }

        $available_by_id = [];
        foreach ($available as $monitor) {
            $available_by_id[(string) $monitor['id']] = $monitor;
        }

        $selected = [];
        foreach ($ids as $id) {
            $key = (string) $id;

            if (isset($available_by_id[$key])) {
                $selected[] = $available_by_id[$key];
            }
        }

        if (!$selected) {
            wp_die('Vybrané monitory nebyly nalezeny.');
        }

        $lists = $this->get_lists();

        $requested_list_id = isset($_POST['list_id'])
            ? sanitize_text_field(wp_unslash($_POST['list_id']))
            : '';

        $list_id = $this->resolve_list_id($requested_list_id, $lists);

        if ($list_id === '' || !isset($lists[$list_id])) {
            $list_id = 'list_' . strtolower(wp_generate_password(8, false, false));
        }

        $lists[$list_id] = [
            'name' => $name,
            'monitors' => $selected,
            'updated_at' => current_time('mysql'),
        ];

        update_option(self::LISTS_OPTION, $lists);

        wp_safe_redirect(add_query_arg(
            ['page' => 'padik-status-manager', 'psm_saved' => 1],
            admin_url('options-general.php')
        ));
        exit;
    }

    public function delete_list() {
        if (!current_user_can('manage_options')) {
            wp_die('Nemáte oprávnění.');
        }

        $requested_list_id = isset($_GET['list_id'])
            ? sanitize_text_field(wp_unslash($_GET['list_id']))
            : '';

        $lists = $this->get_lists();
        $list_id = $this->resolve_list_id($requested_list_id, $lists);

        if ($list_id === '') {
            wp_die('Seznam nebyl nalezen.');
        }

        check_admin_referer('psm_delete_list_' . $list_id);

        unset($lists[$list_id]);
        update_option(self::LISTS_OPTION, $lists);

        wp_safe_redirect(add_query_arg(
            ['page' => 'padik-status-manager', 'psm_deleted' => 1],
            admin_url('options-general.php')
        ));
        exit;
    }

    public function register_rest_routes() {
        register_rest_route('padik-status/v1', '/heartbeat', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'rest_heartbeat'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function rest_heartbeat() {
        $settings = $this->get_settings();

        $url = untrailingslashit($settings['kuma_url'])
            . '/api/status-page/heartbeat/'
            . rawurlencode($settings['slug']);

        $response = wp_remote_get($url, [
            'timeout' => 15,
            'redirection' => 3,
            'headers' => [
                'Accept' => 'application/json',
                'User-Agent' => 'Padik-Status-Manager/' . PSM_VERSION,
            ],
        ]);

        if (is_wp_error($response)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $response->get_error_message(),
            ], 502);
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($status !== 200 || !is_array($data)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Uptime Kuma vrátila neplatnou odpověď.',
            ], 502);
        }

        $rest = new WP_REST_Response($data, 200);
        $rest->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');

        return $rest;
    }

    public function register_front_assets() {
        wp_register_style(
            'psm-widget',
            PSM_URL . 'assets/widget.css',
            [],
            PSM_VERSION
        );

        wp_register_script(
            'psm-widget',
            PSM_URL . 'assets/widget.js',
            [],
            PSM_VERSION,
            true
        );
    }

    public function shortcode($atts) {
        $atts = shortcode_atts([
            'list' => '',
        ], $atts, 'padik_status');

        return $this->render_list((string) $atts['list']);
    }

    private function resolve_list_id($list_id, $lists) {
        $list_id = trim((string) $list_id);

        if ($list_id === '') {
            return '';
        }

        if (isset($lists[$list_id])) {
            return $list_id;
        }

        $sanitized = sanitize_key($list_id);

        if (isset($lists[$sanitized])) {
            return $sanitized;
        }

        foreach (array_keys($lists) as $saved_id) {
            if (strtolower($saved_id) === strtolower($list_id)) {
                return $saved_id;
            }

            if (sanitize_key($saved_id) === $sanitized) {
                return $saved_id;
            }
        }

        return '';
    }

    public function render_list($list_id) {
        $lists = $this->get_lists();
        $list_id = $this->resolve_list_id($list_id, $lists);

        if (!$list_id || !isset($lists[$list_id])) {
            return current_user_can('manage_options')
                ? '<p><strong>Padik Status:</strong> Vybraný seznam neexistuje.</p>'
                : '';
        }

        $settings = $this->get_settings();
        $list = $lists[$list_id];

        wp_enqueue_style('psm-widget');
        wp_enqueue_script('psm-widget');

        wp_localize_script('psm-widget', 'PSMWidget', [
            'endpoint' => esc_url_raw(rest_url('padik-status/v1/heartbeat')),
            'refreshInterval' => max(10, absint($settings['refresh_interval'])) * 1000,
        ]);

        ob_start();
        ?>
        <div class="psm-status" data-psm-widget>
            <?php foreach ($list['monitors'] as $monitor) : ?>
                <div class="psm-status-card" data-monitor-id="<?php echo esc_attr($monitor['id']); ?>">
                    <div class="psm-service-name"><?php echo esc_html($monitor['name']); ?></div>
                    <span class="psm-status-dot is-loading" aria-label="Načítání"></span>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function maybe_register_elementor() {
        if (!did_action('elementor/loaded')) {
            return;
        }

        add_action(
            'elementor/widgets/register',
            [$this, 'register_elementor_widget']
        );
    }

    public function register_elementor_widget($widgets_manager) {
        if (!class_exists('\Elementor\Widget_Base')) {
            return;
        }

        require_once PSM_DIR . 'includes/class-psm-elementor-widget.php';

        if (class_exists('PSM_Elementor_Widget')) {
            $widgets_manager->register(new PSM_Elementor_Widget());
        }
    }

    public function plugin_links($links) {
        array_unshift(
            $links,
            '<a href="' . esc_url(admin_url('options-general.php?page=padik-status-manager')) . '">Nastavení</a>'
        );

        return $links;
    }
}
